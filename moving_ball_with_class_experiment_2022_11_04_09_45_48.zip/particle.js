//------------------OOP:Class Particle
class Particle {
  //  Constructor Function:properties
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.xSpd = random(-3, 1);
    this.ySpd = random(-3, 1);
    this.xdia = random(20, 30);
    this.ydia = random(30, 50);
    this.scaleAmount = random(5, 10);
    this.rotAngle = random(TWO_PI); // radians
    this.rotSpd = random(0.01, 0.02);
  }

  // methods
  move() {
    this.x += this.xSpd;
    this.y += this.ySpd;
  }

  //  Particle's appearance
  display() {
    push();
    translate(this.x, this.y);
    rotate(this.rotAngle);
    // Design the particle's appearance here.
    // YOUR CODE GOES HERE:
    noStroke();
    fill("#f9a875");
    ellipse(0, 0, this.xdia, this.ydia);
    fill("#eb6b6f");
    ellipse(
      this.scaleAmount,
      this.scaleAmount,
      this.ydia + this.scaleAmount,
      this.xdia + this.scaleAmount
    );
    fill("#8be5ff");
    ellipse(-10, 0, this.scaleAmount * 3, this.scaleAmount * 3);

    pop();
  }
  // Implement (at least three) more methods(functions) for the particle's behaviors

  // Design the 1st behavior/method for your Particle
  // YOUR CODE GOES HERE:
  reappear() {
    if (this.x < 0) {
      this.x = imgW;
      this.xSpd = random(-3, 1);
    } else if (this.x > imgH) {
      this.x = 0;
      this.xSpd = random(-3, 1);
    }
    if (this.y < 0) {
      this.y = imgW;
      this.ySpd = random(-3, 1);
    } else if (this.y > imgH) {
      this.y = 0;
      this.ySpd = random(-3, 1);
    }
  }

  bounce() {
    if (this.x < 0 || this.x > width) {
      this.xSpd *= -1;
    }
    if (this.y < 0 || this.y > height) {
      this.ySpd *= -1;
    }
  }
  // Design the 2nd behavior/method for your Particle
  // YOUR CODE GOES HERE:
  repelledFrom(targetX, targetY) {
    // With dist(), we can easily get the distance
    // between the particle's current position and the target position.
    let distance = dist(this.x, this.y, targetX, targetY);
    // If the distance is too close (less than 30),
    // we apply the repelling acceleration (actually Force in Physics)
    if (distance < 30) {
      // By calculating "target position - this position"
      // we can get the direction to the target.
      // Then we FLIP the direction by multiplying with -1.
      // We also arbitrary decrease the acceleration to reach the target
      let xAcc = (targetX - this.x) * -1 * random(-0.2,-0.1);
      let yAcc = (targetY - this.y) * -1 * random(-0.2,-0.1);
      this.xSpd += xAcc;
      this.ySpd += yAcc;
      this.xSpd = constrain(this.xSpd,-2,2);
      this.ySpd = constrain(this.xSpd,-2,2);
    }
  }

  // Design the 3rd behavior/method for your Particle
  // YOUR CODE GOES HERE:

  rotate() {
    this.rotAngle += this.rotSpd;
  }
  // *Design more behavior/method for your Particle* [optional]
  // YOUR CODE GOES HERE:
}