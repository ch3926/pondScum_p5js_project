// flashlight functionality reference: https://editor.p5js.org/ebenjmuse/sketches/rJUFyTjbz

let rectSize = 30;
let particles = [];
let totalNum = 1; // Decide the number of particles here.
let imgW;
let imgH;


function preload() {
  img = loadImage("bg.png");
}

function setup() {
  imgW = img.width;
  imgH = img.height;
  createCanvas(imgW,imgH);
  user = new User(imgW / 2, imgH / 2);

  // adding particles
  for (let i = 0; i < totalNum; i++) {
    particles[i] = new Particle(random(imgW), random(imgH));
  }
  
  // loading image setup
  pixelDensity(1);
  
}

function draw() {
  // flashlight ---------------------
  loadPixels();
	var lightRadius = 180;
  // We must also call loadPixels() on the PImage since we are going to read its pixels.
  img.loadPixels();
  for (var y = 0; y < height; y++ ) {
    for (var x = 0; x < width; x++ ) {
      var loc = (x + y * width) * 4;
      // The functions red(), green(), and blue() pull out the three color components from a pixel.
      var r = img.pixels[loc   ]; 
      var g = img.pixels[loc + 1];
      var b = img.pixels[loc + 2];

      // Calculate an amount to change brightness
      // based on proximity to the mouse
      var distance = dist(x, y, user.x, user.y);

      // The closer the pixel is to the mouse, the lower the value of "distance" 
      // We want closer pixels to be brighter, however, so we invert the value using map()
      // Pixels with a distance greater than the lightRadius have a brightness of 0.0 
      // (or negative which is equivalent to 0 here)
      // Pixels with a distance of 0 have a brightness of 1.0.
      var adjustBrightness = map(distance, 0, lightRadius, 1, 0);
      r *= adjustBrightness;
      g *= adjustBrightness;
      b *= adjustBrightness;

      // Constrain RGB to between 0-255
      r = constrain(r, 0, 255);
      g = constrain(g, 0, 255);
      b = constrain(b, 0, 255);
      
      // Set the display pixel to the image pixel
      pixels[loc    ] = r;
      pixels[loc + 1] = g;
      pixels[loc + 2] = b;
      pixels[loc + 3] = 255; // Always have to set alpha
    }
  }

  updatePixels();
  // pixels end -----------------
  
  
  //background("#fff6d3");

  // defining user movement
  if (user.x > 25 && keyIsDown(65)) { // 65 is left keycode
    user.x -= 5;
  }

  if (user.x < imgW - 25 && keyIsDown(68)) {
    user.x += 5;
  }

  if (user.y > 25 && keyIsDown(87)) {
    user.y -= 5;
  }

  if (user.y < imgH - 25 && keyIsDown(83)) {
    user.y += 5;
  }
  
  user.display();

  //  Particles update and display
  for (let i = 0; i < particles.length; i++) {
    particles[i].repelledFrom(user.x, user.y);
    particles[i].move();
    particles[i].reappear();
    particles[i].display();
    particles[i].rotate();
  }
}

//  Design interactions by using Mouse or Keyboard
function mousePressed() {
  //..generate an object when mousePressed at the location of  mouseX,mouseY
  //particles.push(new Particle(mouseX, mouseY));
}

function keyPressed() {
  // use backspace button to delete!
  if (keyCode === BACKSPACE) {
    // and if there is at least one object
    if (particles.length > 0) {
      let index = 0; // the first index = the oldest object
      particles.splice(index, 1);
    }
  }
  else if (keyCode === 32){ // spacebar keycode is 32
    particles.push(new Particle(user.x, user.y));
  }
}

//----------------------------------OOP:Class User

class User {
  constructor(startX, startY) {
    this.x = startX;
    this.y = startY;
  }

  display(self) {
    noStroke();
    fill(255, 0, 0, 63);
    ellipse(this.x, this.y, 50, 50);
    fill("white");
    ellipse(this.x, this.y, 20, 20);
  }
}

//----------------------------------OOP:Class Particle
class Particle {
  //  Constructor Function:properties
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.xSpd = random(-3, 1);
    this.ySpd = random(-3, 1);
    this.xdia = random(20, 30);
    this.ydia = random(30, 50);
    this.scaleAmount = random(5, 10);
    this.rotAngle = random(TWO_PI); // radians
    this.rotSpd = random(0.01, 0.02);
  }

  // methods
  move() {
    this.x += this.xSpd;
    this.y += this.ySpd;
  }

  //  Particle's appearance
  display() {
    push();
    translate(this.x, this.y);
    rotate(this.rotAngle);
    // Design the particle's appearance here.
    // YOUR CODE GOES HERE:
    noStroke();
    fill("#f9a875");
    ellipse(0, 0, this.xdia, this.ydia);
    fill("#eb6b6f");
    ellipse(
      this.scaleAmount,
      this.scaleAmount,
      this.ydia + this.scaleAmount,
      this.xdia + this.scaleAmount
    );
    fill("#8be5ff");
    ellipse(-10, 0, this.scaleAmount * 3, this.scaleAmount * 3);

    pop();
  }
  // Implement (at least three) more methods(functions) for the particle's behaviors

  // Design the 1st behavior/method for your Particle
  // YOUR CODE GOES HERE:
  reappear() {
    if (this.x < 0) {
      this.x = imgW;
      this.xSpd = random(-3, 1);
    } else if (this.x > imgH) {
      this.x = 0;
      this.xSpd = random(-3, 1);
    }
    if (this.y < 0) {
      this.y = imgW;
      this.ySpd = random(-3, 1);
    } else if (this.y > imgH) {
      this.y = 0;
      this.ySpd = random(-3, 1);
    }
  }
  // Design the 2nd behavior/method for your Particle
  // YOUR CODE GOES HERE:
  repelledFrom(targetX, targetY) {
    // With dist(), we can easily get the distance
    // between the particle's current position and the target position.
    let distance = dist(this.x, this.y, targetX, targetY);
    // If the distance is too close (less than 30),
    // we apply the repelling acceleration (actually Force in Physics)
    if (distance < 30) {
      // By calculating "target position - this position"
      // we can get the direction to the target.
      // Then we FLIP the direction by multiplying with -1.
      // We also arbitrary decrease the acceleration to reach the target
      let xAcc = (targetX - this.x) * -1 * -0.2;
      let yAcc = (targetY - this.y) * -1 * -0.2;
      this.xSpd += xAcc;
      this.ySpd += yAcc;
    }
  }

  // Design the 3rd behavior/method for your Particle
  // YOUR CODE GOES HERE:

  rotate() {
    this.rotAngle += this.rotSpd;
  }
  // *Design more behavior/method for your Particle* [optional]
  // YOUR CODE GOES HERE:
}
