let rectSize = 30;

function setup() {
  createCanvas(400, 400);
  user = new User(width / 2, height / 2);
}

function draw() {
  background(0);

  rectMode(CENTER);
  noStroke();

  fill(25, 132, 134);
  // rect(x, y, w, h, [detailX], [detailY])
  rect(width / 2, height / 2 + 30, 300, 300);

  // grey square
  fill(156, 152, 142); // new color, only modifies stuff below
  rect(width / 2, height / 2 + 60, 200, 200);

  // yellow center square
  fill(219, 171, 77);
  rect(width / 2, height / 2 + 90, 100, 100);
  //x = x + 1;

  
  // defining user movement
  if (user.x > 25 && keyIsDown(LEFT_ARROW)) {
      user.x -=5;
    }

    if (user.x < width - 25 && keyIsDown(RIGHT_ARROW)) {
      user.x += 5;
    }

    if (user.y > 25 && keyIsDown(UP_ARROW)) {
      user.y -= 5;
    }

    if (user.y < height - 25 && keyIsDown(DOWN_ARROW)) {
      user.y += 5;
   }
  user.display();
  
}

class User {
  constructor(startX, startY) {
    this.x = startX;
    this.y = startY;
  }

  display(self) {
    
    noStroke();
    fill(255, 0, 0, 63);
    ellipse(this.x,this.y, 50, 50);
    fill("white");
    ellipse(this.x,this.y, 20, 20);
    
  }
}
