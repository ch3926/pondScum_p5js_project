//----------------------------------OOP:Class User

class User {
  constructor(startX, startY) {
    this.x = startX;
    this.y = startY;
  }

  display(self, frog) {
    
    noStroke();  
    
    // head
    fill("cyan");
    ellipse(this.x, this.y, 40, 30);
    // eyes
    fill("white");
    ellipse(this.x-10, this.y-10, 20, 20);
    ellipse(this.x+10, this.y-10, 20, 20);
    fill("black");
    ellipse(this.x-5, this.y-10, 5, 5);
    ellipse(this.x+5, this.y-10, 5, 5);
    
    // nose
    fill("pink")
    ellipse(this.x,this.y+5,10)
    
    // arms
    push();
    fill("black");
    rect(this.x+20, this.y, 10, 2);
    rect(this.x-30, this.y, 10, 2);
    pop();
    
    
  }
}
